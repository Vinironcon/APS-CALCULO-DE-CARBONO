"""Geracao de relatorios (texto, CSV) e historico em JSON."""
import csv
import json
from datetime import datetime

from calculos import comparar_projetos, sugerir_reducao
from fatores import FATORES

DICAS = {
    "energia": "Troque lampadas por LED, desligue aparelhos em standby e avalie energia solar.",
    "combustivel": "Prefira etanol, mantenha o veiculo regulado e combine trajetos.",
    "viagem": "Substitua trechos curtos por transporte coletivo, bicicleta ou caminhada.",
    "residuos": "Separe recicláveis e compostáveis para reduzir o envio ao aterro.",
}


def montar_relatorio(inv, cambio):
    """Retorna o relatorio completo como string."""
    linhas = []
    linhas.append("=" * 60)
    linhas.append("RELATORIO DE PEGADA DE CARBONO")
    linhas.append("=" * 60)
    linhas.append(f"Perfil: {inv.perfil}   Nome: {inv.nome or '-'}")
    linhas.append(f"Data: {datetime.now():%d/%m/%Y %H:%M}")
    linhas.append("")
    linhas.append("Detalhamento dos lancamentos:")
    for l in inv.lancamentos:
        f = FATORES[l["categoria"]][l["item"]]
        linhas.append(f"  {f['nome']:<36} {l['quantidade']:>10.2f} {f['unidade']:<4}"
                      f" -> {l['kg']:>10.2f} kgCO2e")
    linhas.append("")
    linhas.append("Emissoes por categoria:")
    total = inv.total_kg()
    for cat, kg in sorted(inv.por_categoria().items(), key=lambda x: -x[1]):
        pct = kg / total * 100 if total else 0
        linhas.append(f"  {cat:<14} {kg:>10.2f} kgCO2e  ({pct:5.1f}%)")
    linhas.append("")
    linhas.append(f"TOTAL: {inv.total_t():.3f} tCO2e")
    if inv.populacao > 1:
        linhas.append(f"Per capita ({inv.populacao} hab.): {inv.per_capita_t():.3f} tCO2e")
    linhas.append("")
    linhas.append(f"Compensacao (cambio R$ {cambio:.2f}/US$):")
    for p in comparar_projetos(inv.total_t(), cambio):
        linhas.append(f"  {p['nome']:<30} {p['tipo']:<8} {p['creditos']:>5} cred."
                      f"  US$ {p['usd']:>10,.2f}  R$ {p['brl']:>12,.2f}")
    sug = sugerir_reducao(inv)
    if sug:
        cat, pct = sug
        linhas.append("")
        linhas.append(f"Maior impacto: {cat} ({pct:.1f}%). {DICAS.get(cat, '')}")
    return "\n".join(linhas)


def salvar_texto(caminho, texto):
    with open(caminho, "w", encoding="utf-8") as arq:
        arq.write(texto + "\n")


def exportar_csv(caminho, inv):
    with open(caminho, "w", newline="", encoding="utf-8") as arq:
        w = csv.writer(arq, delimiter=";")
        w.writerow(["categoria", "item", "quantidade", "kgCO2e"])
        for l in inv.lancamentos:
            w.writerow([l["categoria"], l["item"], l["quantidade"], round(l["kg"], 4)])


def salvar_historico(caminho, inv):
    """Acrescenta o resultado ao arquivo de historico (JSON)."""
    try:
        with open(caminho, encoding="utf-8") as arq:
            historico = json.load(arq)
    except (FileNotFoundError, json.JSONDecodeError):
        historico = []
    historico.append({
        "data": datetime.now().isoformat(timespec="seconds"),
        "perfil": inv.perfil, "nome": inv.nome,
        "total_t": round(inv.total_t(), 4),
    })
    with open(caminho, "w", encoding="utf-8") as arq:
        json.dump(historico, arq, ensure_ascii=False, indent=2)
    return historico


def ler_historico(caminho):
    try:
        with open(caminho, encoding="utf-8") as arq:
            return json.load(arq)
    except (FileNotFoundError, json.JSONDecodeError):
        return []
