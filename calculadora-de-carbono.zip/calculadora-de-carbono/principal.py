"""Interface de linha de comando da Calculadora de Carbono."""
from calculos import Inventario, ErroDeEntrada
from fatores import FATORES, PROJETOS, CAMBIO_PADRAO, ANO_REFERENCIA
from relatorios import (montar_relatorio, salvar_texto, exportar_csv,
                        salvar_historico, ler_historico)

ARQ_HISTORICO = "historico.json"


def ler_numero(mensagem, minimo=0.0, inteiro=False):
    """Le um numero validado; repete ate o usuario informar um valor correto."""
    while True:
        bruto = input(mensagem).strip().replace(",", ".")
        try:
            valor = int(bruto) if inteiro else float(bruto)
        except ValueError:
            print("  Entrada invalida: digite um numero.")
            continue
        if valor < minimo:
            print(f"  O valor deve ser maior ou igual a {minimo}.")
            continue
        return valor


def escolher(titulo, opcoes):
    """Mostra uma lista numerada e devolve a chave escolhida."""
    chaves = list(opcoes)
    print(f"\n{titulo}")
    for i, k in enumerate(chaves, 1):
        print(f"  {i}) {opcoes[k]}")
    n = int(ler_numero("Opcao: ", 1, inteiro=True))
    while n > len(chaves):
        print("  Opcao inexistente.")
        n = int(ler_numero("Opcao: ", 1, inteiro=True))
    return chaves[n - 1]


def criar_inventario():
    perfis = {"individuo": "Individuo", "empresa": "Empresa", "cidade": "Cidade"}
    perfil = escolher("Perfil do inventario:", perfis)
    nome = input("Nome (opcional): ").strip()
    pop = 1
    if perfil == "cidade":
        pop = int(ler_numero("Populacao da cidade: ", 1, inteiro=True))
    return Inventario(perfil, nome, pop)


def lancar_consumo(inv):
    cats = {c: c.capitalize() for c in FATORES}
    cat = escolher("Categoria de emissao:", cats)
    itens = {k: f"{v['nome']} ({v['unidade']})" for k, v in FATORES[cat].items()}
    item = escolher("Fonte:", itens)
    unidade = FATORES[cat][item]["unidade"]
    qtd = ler_numero(f"Quantidade consumida em {unidade}: ")
    kg = inv.adicionar(cat, item, qtd)
    print(f"  -> {kg:.2f} kgCO2e adicionados.")


def mostrar_projetos():
    print("\nProjetos de compensacao (US$/tCO2e):")
    for d in PROJETOS.values():
        print(f"  {d['nome']:<30} {d['tipo']:<8} US$ {d['preco_usd']:>7.2f}"
              f"  - {d['descricao']}")
    print("  Precos de referencia; valores reais variam conforme o projeto.")


def menu():
    print("=" * 50)
    print(" CALCULADORA DE CARBONO - IPE/UNIP")
    print(f" Fatores de referencia (base {ANO_REFERENCIA})")
    print("=" * 50)
    inv = criar_inventario()
    cambio = CAMBIO_PADRAO
    while True:
        print(f"\nTotal atual: {inv.total_t():.3f} tCO2e")
        opcao = escolher("Menu:", {
            "lancar": "Lancar consumo",
            "ver": "Ver relatorio completo",
            "projetos": "Consultar projetos e precos",
            "cambio": "Alterar cambio",
            "salvar": "Salvar relatorio (TXT/CSV) e historico",
            "hist": "Ver historico de calculos",
            "sair": "Sair"})
        if opcao == "lancar":
            lancar_consumo(inv)
        elif opcao == "ver":
            print("\n" + montar_relatorio(inv, cambio))
        elif opcao == "projetos":
            mostrar_projetos()
        elif opcao == "cambio":
            cambio = ler_numero("Novo cambio (R$ por US$): ", 0.01)
        elif opcao == "salvar":
            salvar_texto("relatorio_carbono.txt", montar_relatorio(inv, cambio))
            exportar_csv("lancamentos.csv", inv)
            salvar_historico(ARQ_HISTORICO, inv)
            print("  Arquivos salvos: relatorio_carbono.txt, lancamentos.csv, historico.json")
        elif opcao == "hist":
            for h in ler_historico(ARQ_HISTORICO):
                print(f"  {h['data']}  {h['perfil']:<10} {h['nome'] or '-':<15} {h['total_t']:.3f} tCO2e")
        else:
            print("Ate logo!")
            break


if __name__ == "__main__":
    try:
        menu()
    except (KeyboardInterrupt, EOFError):
        print("\nExecucao encerrada.")
