# Calculadora de Carbono

Calculadora de pegada de carbono em Python, executada no terminal. Estima as emissões de gases de efeito estufa (tCO₂e) de **indivíduos, empresas e cidades**, calcula quantos créditos de carbono seriam necessários para compensá-las e compara o custo entre diferentes tipos de projeto, em dólares e em reais.

Projeto da APS de *Introdução à Programação Estruturada* (IPE), curso de Ciência da Computação, UNIP – Campus Marques.

**Autor:** Vinicius Alves Roncon · **Orientador:** Luiz Santos

## Funcionalidades

- Três perfis: indivíduo, empresa e cidade (com emissão per capita)
- Categorias de emissão: energia, combustíveis, viagens e resíduos
- Cálculo de créditos de carbono e custo da compensação (US$ e R$, com câmbio ajustável)
- Comparação de projetos: reflorestamento, REDD+, energia renovável, fogões eficientes e captura direta do ar
- Sugestão da categoria prioritária para redução
- Relatório em TXT, exportação em CSV e histórico em JSON
- Validação de entradas e tratamento de erros (aceita vírgula decimal)

## Requisitos

Python 3.8 ou superior. Não há dependências externas, apenas a biblioteca padrão.

## Como executar

```bash
python principal.py
```

Para rodar os testes automatizados:

```bash
python -m unittest -v
```

## Estrutura

| Arquivo | Responsabilidade |
|---|---|
| `principal.py` | Menu, leitura validada de dados e fluxo do programa |
| `calculos.py` | Emissões, inventário, créditos, custos, comparação e sugestão |
| `relatorios.py` | Relatório em texto, exportação CSV e histórico JSON |
| `fatores.py` | Fatores de emissão e catálogo de projetos de compensação |
| `test_calculadora.py` | Testes automatizados (`unittest`) |

## Fórmulas

```
E (kg CO₂e) = atividade × fator de emissão
créditos    = ⌈E_total / 1000⌉
custo (R$)  = créditos × preço (US$) × câmbio
```

## Aviso

Somente o fator de emissão da eletricidade (MCTI, média anual do SIN em 2023) é oficial. Os demais fatores e os preços dos créditos são valores de referência com finalidade didática e devem ser atualizados antes de qualquer uso profissional. O programa estima emissões, mas **não** emite, certifica nem aposenta créditos, e não substitui um inventário auditado.
