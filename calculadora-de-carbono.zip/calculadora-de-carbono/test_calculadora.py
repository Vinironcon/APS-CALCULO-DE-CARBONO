import unittest
from calculos import (Inventario, calcular_emissao, creditos_necessarios,
                      custo_compensacao, comparar_projetos, ErroDeEntrada,
                      sugerir_reducao)


class TestCalculos(unittest.TestCase):
    def test_emissao_eletricidade(self):
        self.assertAlmostEqual(calcular_emissao("energia", "eletricidade", 1000), 38.5)

    def test_emissao_gasolina(self):
        self.assertAlmostEqual(calcular_emissao("combustivel", "gasolina", 100), 220.0)

    def test_quantidade_negativa(self):
        with self.assertRaises(ErroDeEntrada):
            calcular_emissao("viagem", "carro", -1)

    def test_fator_inexistente(self):
        with self.assertRaises(ErroDeEntrada):
            calcular_emissao("viagem", "foguete", 10)

    def test_inventario_total_e_categoria(self):
        inv = Inventario()
        inv.adicionar("combustivel", "gasolina", 100)   # 220 kg
        inv.adicionar("viagem", "aviao", 1000)          # 150 kg
        self.assertAlmostEqual(inv.total_kg(), 370.0)
        self.assertAlmostEqual(inv.por_categoria()["viagem"], 150.0)

    def test_creditos_arredondam_para_cima(self):
        self.assertEqual(creditos_necessarios(2.01), 3)
        self.assertEqual(creditos_necessarios(0), 0)

    def test_custo_reflorestamento(self):
        c, usd, brl = custo_compensacao(2.5, "reflorestamento", 5.0)
        self.assertEqual(c, 3)
        self.assertAlmostEqual(usd, 72.0)
        self.assertAlmostEqual(brl, 360.0)

    def test_comparacao_ordenada(self):
        r = comparar_projetos(10)
        custos = [x["usd"] for x in r]
        self.assertEqual(custos, sorted(custos))

    def test_per_capita(self):
        inv = Inventario("cidade", "X", 1000)
        inv.adicionar("combustivel", "diesel", 1_000_000)  # 2600 t
        self.assertAlmostEqual(inv.per_capita_t(), 2.6)

    def test_populacao_invalida(self):
        with self.assertRaises(ErroDeEntrada):
            Inventario(populacao=0)

    def test_sugestao(self):
        inv = Inventario()
        inv.adicionar("energia", "eletricidade", 100)
        inv.adicionar("combustivel", "diesel", 100)
        self.assertEqual(sugerir_reducao(inv)[0], "combustivel")


if __name__ == "__main__":
    unittest.main()
