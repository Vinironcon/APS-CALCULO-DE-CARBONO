"""Base de dados de fatores de emissao e projetos de compensacao.

Todos os fatores estao em kg de CO2e por unidade. Os valores sao de referencia
e ficam isolados neste modulo para que possam ser atualizados sem alterar a
logica do programa.
"""

ANO_REFERENCIA = 2025
CAMBIO_PADRAO = 5.50  # R$ por US$ (valor didatico; o usuario pode alterar)

# categoria -> item -> dados
FATORES = {
    "energia": {
        "eletricidade": {
            "nome": "Eletricidade da rede (SIN)", "unidade": "kWh",
            "fator": 0.0385,
            "fonte": "MCTI - fator medio anual do SIN, 2023 (0,0385 tCO2/MWh)",
        },
        "gas_glp": {
            "nome": "Gas de cozinha (GLP)", "unidade": "kg",
            "fator": 2.94, "fonte": "Estimativa baseada em GHG Protocol/IPCC",
        },
    },
    "combustivel": {
        "gasolina": {
            "nome": "Gasolina automotiva", "unidade": "L",
            "fator": 2.20, "fonte": "Estimativa baseada em GHG Protocol Brasil",
        },
        "etanol": {
            "nome": "Etanol hidratado (parcela fossil)", "unidade": "L",
            "fator": 0.08, "fonte": "Estimativa baseada em GHG Protocol Brasil",
        },
        "diesel": {
            "nome": "Diesel", "unidade": "L",
            "fator": 2.60, "fonte": "Estimativa baseada em GHG Protocol Brasil",
        },
        "gnv": {
            "nome": "Gas natural veicular (GNV)", "unidade": "m3",
            "fator": 2.00, "fonte": "Estimativa baseada em GHG Protocol Brasil",
        },
    },
    "viagem": {
        "carro": {
            "nome": "Carro de passeio", "unidade": "km",
            "fator": 0.15, "fonte": "Estimativa didatica (media de frota)",
        },
        "moto": {
            "nome": "Motocicleta", "unidade": "km",
            "fator": 0.09, "fonte": "Estimativa didatica",
        },
        "onibus": {
            "nome": "Onibus urbano/rodoviario", "unidade": "km",
            "fator": 0.07, "fonte": "Estimativa didatica (por passageiro)",
        },
        "metro": {
            "nome": "Metro/trem eletrico", "unidade": "km",
            "fator": 0.01, "fonte": "Estimativa didatica (matriz eletrica limpa)",
        },
        "aviao": {
            "nome": "Aviao", "unidade": "km",
            "fator": 0.15, "fonte": "Estimativa didatica (por passageiro)",
        },
    },
    "residuos": {
        "aterro": {
            "nome": "Residuos enviados a aterro", "unidade": "kg",
            "fator": 0.45, "fonte": "Estimativa didatica",
        },
    },
}

# Projetos de reducao/remocao de emissoes (preco em US$ por tCO2e)
PROJETOS = {
    "reflorestamento": {
        "nome": "Reflorestamento (ARR)", "tipo": "Remocao",
        "preco_usd": 24.0,
        "fonte": "Sylvera, set/2025 (alta qualidade, preco a vista)",
        "descricao": "Plantio e restauracao de florestas nativas.",
    },
    "protecao_florestal": {
        "nome": "Protecao florestal (REDD+)", "tipo": "Reducao",
        "preco_usd": 8.0, "fonte": "Estimativa didatica",
        "descricao": "Evita o desmatamento de florestas ameacadas.",
    },
    "energia_renovavel": {
        "nome": "Energia renovavel", "tipo": "Reducao",
        "preco_usd": 2.5, "fonte": "Estimativa didatica",
        "descricao": "Usinas solares, eolicas e hidreletricas.",
    },
    "fogoes_eficientes": {
        "nome": "Fogoes eficientes", "tipo": "Reducao",
        "preco_usd": 10.0, "fonte": "Estimativa didatica",
        "descricao": "Substitui fogoes a lenha por modelos eficientes.",
    },
    "captura_direta": {
        "nome": "Captura direta do ar (DAC)", "tipo": "Remocao",
        "preco_usd": 600.0, "fonte": "Estimativa didatica",
        "descricao": "Remocao tecnologica de CO2 da atmosfera.",
    },
}
