"""Nucleo de calculo: emissoes, creditos de carbono e custos."""
import math

from fatores import FATORES, PROJETOS, CAMBIO_PADRAO


class ErroDeEntrada(ValueError):
    """Sinaliza dado de entrada invalido."""


def obter_fator(categoria, item):
    """Retorna o dicionario do fator ou levanta ErroDeEntrada."""
    try:
        return FATORES[categoria][item]
    except KeyError:
        raise ErroDeEntrada(f"Fator inexistente: {categoria}/{item}")


def calcular_emissao(categoria, item, quantidade):
    """Emissao em kg de CO2e = quantidade x fator."""
    if quantidade < 0:
        raise ErroDeEntrada("A quantidade nao pode ser negativa.")
    return quantidade * obter_fator(categoria, item)["fator"]


class Inventario:
    """Conjunto de lancamentos de consumo de um individuo, empresa ou cidade."""

    def __init__(self, perfil="individuo", nome="", populacao=1):
        if populacao < 1:
            raise ErroDeEntrada("A populacao deve ser de ao menos 1.")
        self.perfil = perfil
        self.nome = nome
        self.populacao = populacao
        self.lancamentos = []

    def adicionar(self, categoria, item, quantidade):
        kg = calcular_emissao(categoria, item, quantidade)
        self.lancamentos.append({
            "categoria": categoria, "item": item,
            "quantidade": quantidade, "kg": kg,
        })
        return kg

    def total_kg(self):
        return sum(l["kg"] for l in self.lancamentos)

    def total_t(self):
        return self.total_kg() / 1000

    def por_categoria(self):
        """Dicionario categoria -> kg de CO2e."""
        resultado = {}
        for l in self.lancamentos:
            resultado[l["categoria"]] = resultado.get(l["categoria"], 0) + l["kg"]
        return resultado

    def per_capita_t(self):
        return self.total_t() / self.populacao


def creditos_necessarios(total_t, arredondar=True):
    """Cada credito equivale a 1 tCO2e; creditos sao comprados inteiros."""
    if total_t < 0:
        raise ErroDeEntrada("Emissao total negativa.")
    return math.ceil(total_t) if arredondar else total_t


def custo_compensacao(total_t, projeto, cambio=CAMBIO_PADRAO):
    """Retorna (creditos, custo em US$, custo em R$)."""
    if cambio <= 0:
        raise ErroDeEntrada("O cambio deve ser positivo.")
    if projeto not in PROJETOS:
        raise ErroDeEntrada(f"Projeto desconhecido: {projeto}")
    creditos = creditos_necessarios(total_t)
    usd = creditos * PROJETOS[projeto]["preco_usd"]
    return creditos, usd, usd * cambio


def comparar_projetos(total_t, cambio=CAMBIO_PADRAO):
    """Lista de projetos ordenada do mais barato para o mais caro."""
    linhas = []
    for chave, dados in PROJETOS.items():
        c, usd, brl = custo_compensacao(total_t, chave, cambio)
        linhas.append({"chave": chave, "nome": dados["nome"],
                       "tipo": dados["tipo"], "creditos": c,
                       "usd": usd, "brl": brl})
    return sorted(linhas, key=lambda x: x["usd"])


def sugerir_reducao(inventario):
    """Aponta a categoria de maior impacto e sua participacao no total."""
    cats = inventario.por_categoria()
    total = inventario.total_kg()
    if not cats or total == 0:
        return None
    maior = max(cats, key=cats.get)
    return maior, cats[maior] / total * 100
